<?php
if (!defined('DIR_CORE')){
	header('Location: static_pages/');
}

class ControllerResponsesExtensionEaseBuzz extends AController{
	public $data = array ();

	public function main(){
		$this->loadLanguage('easebuzz/easebuzz');
		

		if (!$this->config->get('easebuzz_test')){
			$this->data['action'] = 'https://pay.easebuzz.in/pay/secure/';
		} else{
			$this->data['action'] = 'https://testpay.easebuzz.in/pay/secure/';
		}


		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		$this->data['key'] = $this->config->get('easebuzz_key');
		$this->data['txnid'] = $this->session->data['order_id'];
		$this->data['amount'] = $this->currency->format($order_info['total'], $order_info['currency'], $order_info['value'], false);
		$this->data['firstname'] = $order_info['payment_firstname'] . ' ' . $order_info['payment_lastname'];
		$this->data['email'] = $order_info['email'];
		$this->data['phone'] = $order_info['telephone'];
		$this->data['productinfo'] = "Payment through AbanteCart";
		$this->data['surl'] = $this->html->getSecureURL('extension/easebuzz/callback');
		$this->data['furl'] = $this->html->getSecureURL('checkout/cart');
		$this->data['address1'] = html_entity_decode($order_info['payment_address_1'], ENT_QUOTES, 'UTF-8');
		$this->data['address2'] = html_entity_decode($order_info['payment_address_2'], ENT_QUOTES, 'UTF-8');
		$this->data['city'] = html_entity_decode($order_info['payment_city'], ENT_QUOTES, 'UTF-8');
		$this->data['country'] = $order_info['payment_iso_code_2'];
		$this->data['zip'] = html_entity_decode($order_info['payment_postcode'], ENT_QUOTES, 'UTF-8');
		$this->data['hash'] = $this->get_hash($this->data,$this->config->get('easebuzz_secret'));

		

		if ($this->request->get['rt'] == 'checkout/guest_step_3'){
			$back_url = $this->html->getSecureURL('checkout/guest_step_2', '&mode=edit', true);
		} else{
			$back_url = $this->html->getSecureURL('checkout/payment', '&mode=edit', true);
		}

		$this->data['back'] = $this->html->buildElement(
				array (
						'type'  => 'button',
						'name'  => 'back',
						'text'  => $this->language->get('button_back'),
						'style' => 'button',
						'href'  => $back_url
				));
		$this->data['button_confirm'] = $this->html->buildElement(
				array (

					'type'  => 'submit',
						'name'  => $this->language->get('button_confirm'),
						'style' => 'button',
				));
		$this->model_checkout_order->confirm($order_id, $this->config->get('easebuzz_initiate_order_status'));
		$this->view->batchAssign($this->data);
		$this->processTemplate('responses/easebuzz.tpl');
	}

	public function callback(){
		    $this->load->model('checkout/order');
			$params = $this->request->post;
			$reverse_hash = $this->reverse_hash($params,$this->config->get('easebuzz_secret'),"success");
			$order_id=$this->session->data['order_id'];
			if($this->request->post['hash']!=$reverse_hash && $order_id !=$this->request->post['txnid'])
			{
				$this->redirect($this->html->getSecureURL('checkout/cart'));
			}
			$order_info = $this->model_checkout_order->getOrder($order_id);
			$this->model_checkout_order->confirm($order_id, $this->config->get('easebuzz_order_status_id'));
			$this->model_checkout_order->updatePaymentMethodData($order_id,$params);
			$this->redirect($this->html->getSecureURL('checkout/success'));
	}

	function reverse_hash ( $params, $salt, $status )
	{

            $posted = array ();
            $hash_string = null;
            if ( ! empty( $params ) ) foreach ( $params as $key => $value )
                    $posted[$key] = htmlentities( $value, ENT_QUOTES );

			$hash_string = "";
            $hash_sequence = "udf10|udf9|udf8|udf7|udf6|udf5|udf4|udf3|udf2|udf1|email|firstname|productinfo|amount|txnid|key";
            $hash_vars_seq = explode( '|', $hash_sequence );
            $hash_string .= $salt . '|' . $status;
            foreach ( $hash_vars_seq as $hash_var ) {
                    $hash_string .= '|';
                    $hash_string .= isset( $posted[$hash_var] ) ? $posted[$hash_var] : '';
            }
            return strtolower( hash( 'sha512', $hash_string ) );
	}
	
	function get_hash ( $params, $salt )
	{
            $posted = array ();


            if ( ! empty( $params ) ) foreach ( $params as $key => $value )
                    $posted[$key] = htmlentities( $value, ENT_QUOTES );

            $hash_sequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";

            $hash_vars_seq = explode( '|', $hash_sequence );
            $hash_string = null;

            foreach ( $hash_vars_seq as $hash_var ) {
                    $hash_string .= isset( $posted[$hash_var] ) ? $posted[$hash_var] : '';
                    $hash_string .= '|';
            }

			$hash_string .= $salt;
            return strtolower( hash( 'sha512', $hash_string ) );
	}
}
