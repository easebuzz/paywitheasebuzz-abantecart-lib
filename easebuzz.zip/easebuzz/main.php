<?php
if ( !defined ( 'DIR_CORE' )) {
	header ( 'Location: static_pages/' );
}

$controllers = array(
    'storefront' => array(
        'responses/extension/easebuzz'
    ),
    'admin'      => array( ),
);

$models = array(
    'storefront' => array( 'extension/easebuzz' ),
    'admin'      => array( ),
);

$languages = array(
    'storefront' => array(
        'easebuzz/easebuzz'),
    'admin'      => array(
        'easebuzz/easebuzz'));
$templates = array(
    'storefront' => array(
        'responses/easebuzz.tpl',
        ),
    'admin'      => array(
        'pages/extension/easebuzz_settings.tpl'
    )
);